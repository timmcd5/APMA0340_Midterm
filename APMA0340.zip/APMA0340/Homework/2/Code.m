S = [2 -1 9; 1 3 -3; -1 -2 1]
SI = inv(S)
A = [2 0 0; 0 3 0; 0 0 -1/3]
b = SI*A*S
[V,D] = eig(b)
a = [-1 2 2; 2 1 4; 3 -1 2]
at = transpose(a)
null(at, 'r')
I2 = [1 0; 0 1]
I3 = [1 0 0; 0 1 0; 0 0 1]
I4 = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1]
I=I3
syms x
syms t
factor(det([x^2-9*x-5 2*x-5 x+6; 5*x-10 x^2-8*x+12 5*x-10; 3*x+13 5*x-9 x^2-7*x+2]))
AA = [x^2-5*x-21 2*x+23 5*x-10; 5*x+10 x^2-4*x-12 5*x+10; 3*x+13 5*x-9 x^2-7*x+2]
factor(det(AA))

AAA = [3 2 5; 5 4 5; 3 5 1]
AAAA = x*I3-AAA
AAAAA = cofactor(AAAA)
AAAAAA = transpose(AAAAA)
factor(det(AAAAAA))

B = [3 2 1; 1 4 2; 3 -2 -1]
BB = x*I3-B
BBB = cofactor(BB)
BBBB = transpose(BBB)
factor(det(BBBB))

C = [1 -2 4; 1 1 3; 4 -2 1]
CC = x*I3-C
CCC = cofactor(CC)
CCCC = transpose(CCC)
factor(det(CCCC))

a1 = [1 -1 1; 2 -1 3; 4 2 1]
[V, D] = eig(a1)
(a1-3*I)*(a1-I)

a2 = [2 -1 8; 1 2 -1; 1 7 -1]
[v, d] = eig(a2)
zz = eig(a2)
zz = zz*t
zz = exp(zz)
eDt = [exp(-5*t) 0 0; 0 exp((-1+3i)*t) 0; 0 0 exp((-1-3i)*t)]
v_inv = inv(v)
eAt = vpa(v*eDt*v_inv)
(a2-(5)*I)*(a2-(-1+3i)*I)

a3 = [-10 -6 -3; 12 8 3; 12 6 5]
[v, d] = eig(a3)
zz = eig(a3)
zz = zz*t
zz = exp(zz)
eDt = [exp(-t) 0 0; 0 exp(2*t) 0; 0 0 exp(2*t)]
v_inv = inv(v)
eAt = vpa(v*eDt*v_inv)
(a3-(5)*I3)*(a3-(-1+3i)*I3)


A=[-1 2 2 1; 7 -3 -4 0]
B=[6 3; -1 0; 0 -4; 2 1]
AB=A*B
BA=B*A
[vv,dd]=eig(AB)
[vvv,ddd]=eig(BA)
null(BA-0*I4)



function C = cofactor(A,i,j)
   %COFACTOR Cofactors and the cofactor matrix.
   %	COFACTOR(A,i,j) returns the cofactor of row i, column j.
   %	COFACTOR(A) returns the matrix C of cofactors.
   if nargin == 3
      % Remove row i and column j to produce the minor.
      M = A;
      M(i,:) = [];
      M(:,j) = [];
      C = (-1)^(i+j)*det(M);
   else
      [n,n] = size(A);
      for i = 1:n
         for j = 1:n
            C(i,j) = cofactor(A,i,j);
         end
      end
   end
 end