%Homework #6 - Jason Katz

%%%Code will take a few minutes to run

%1


%f(x) ~ a0/2 + sum(k=1 to inf)[ak*cos(k*pi*x/l) + bk*sin(k*pi*x/l)]
%with  l=2 >> f(x) ~ a0/2 + sum(k=1 to inf)[ak*cos(k*pi*x/2) + bk*sin(k*pi*x/2)]
%a0 = .5*int(-2 to 0)dx + .5*int(0 to 2)x^2 dx = 7/3
%ak = .5*int(-2 to 0)cos(k*pi*x/2) dx + .5*int(0 to
%2)x^2*cos(k*pi*x/2) dx = 8/(k^2*pi^2)*(-1)^k
%bk = .5*int(-2 to 0)sin(k*pi*x/2) dx + .5*int(0 to
%2)x^2*sin(k*pi*x/2) dx = -(3*(-1)^k+1)/(k*pi) - 8/(k^3*pi^3)*[1-(-1)^k]

%b

syms k
F5 = @(x) 7/6 + symsum(8*(-1)^k/k^2/pi^2 * cos(k*pi*x/2) + -((3*(-1)^k + 1)/k/pi + 8/k^3/pi^3*(1 - (-1)^k)) * sin(k*pi*x/2),k,1,5)
figure()
plot(-5:.1:5, F5(-5:.1:5))
title('F5')
F20 = @(x) 7/6 + symsum(8*(-1)^k/k^2/pi^2 * cos(k*pi*x/2) + -((3*(-1)^k + 1)/k/pi + 8/k^3/pi^3*(1 - (-1)^k)) * sin(k*pi*x/2),k,1,20)
figure()
plot(-5:.1:5, F20(-5:.1:5))
title('F20')
F100 = @(x) 7/6 + symsum(8*(-1)^k/k^2/pi^2 * cos(k*pi*x/2) + -((3*(-1)^k + 1)/k/pi + 8/k^3/pi^3*(1 - (-1)^k)) * sin(k*pi*x/2),k,1,100)
figure()
plot(-5:.1:5, F100(-5:.1:5))
title('F100')

%c

%Cn(x) = a0/2 + sum(k=1 to N)[(1 - k/(N+1))*(ak*cos(k*pi*x/l) + bk*sin(k*pi*x/l))]
%a0 = .5*int(-2 to 0)dx + .5*int(0 to 2)x^2 dx = 7/3
%ak = .5*int(-2 to 0)cos(k*pi*x/2) dx + .5*int(0 to
%2)x^2*cos(k*pi*x/2) dx = 8/(k^2*pi^2)*(-1)^k
%bk = .5*int(-2 to 0)sin(k*pi*x/2) dx + .5*int(0 to
%2)x^2*sin(k*pi*x/2) dx = -(3*(-1)^k+1)/(k*pi) - 8/(k^3*pi^3)*[1-(-1)^k]

%d

Ce5 = @(x) 7/6 + symsum((1 - k/6)*(8*(-1)^k/k^2/pi^2 * cos(k*pi*x/2) + -((3*(-1)^k + 1)/k/pi + 8/k^3/pi^3*(1 - (-1)^k))*sin(k*pi*x/2)), k, 1, 5)
figure()
plot(-5:.1:5,Ce5(-5:.1:5))
title('Ce5')
Ce20 = @(x) 7/6 + symsum((1 - k/6)*(8*(-1)^k/k^2/pi^2 * cos(k*pi*x/2) + -((3*(-1)^k + 1)/k/pi + 8/k^3/pi^3*(1 - (-1)^k))*sin(k*pi*x/2)), k, 1, 20)
figure()
plot(-5:.1:5,Ce20(-5:.1:5))
title('Ce20')
Ce100 = @(x) 7/6 + symsum((1 - k/6)*(8*(-1)^k/k^2/pi^2 * cos(k*pi*x/2) + -((3*(-1)^k + 1)/k/pi + 8/k^3/pi^3*(1 - (-1)^k))*sin(k*pi*x/2)), k, 1, 100)
figure()
plot(-5:.1:5,Ce100(-5:.1:5))
title('Ce100')

%2

syms a
syms x
syms n
f = @(x) a*sin(x)/(1-2*a*cos(x)+a^2)
a0 = eval(1/pi*int(f,x,-pi,pi))
an = eval(1/pi*int(f*cos(n*x),x,-pi,pi))
bn = eval(1/pi*int(f*sin(n*x),x,-pi,pi))
fx = .5*a0 + symsum(an*cos(n*x),n,1,inf) + symsum(bn*sin(n*x),n,1,inf)

%3

%a

%f(x) ~ a0/2 + sum(k=1 to inf)[ak*cos(k*pi*x)+bk*sin(k*pi*x)]
%a0 = int(from 0 to 2)x^2 dx = 8/3
%ak = int(from 0 to 2)x^2*cos(k*pi*x)dx = 4/(k^2*pi^2)
%bk = int(from 0 to 2)x^2*sin(k*pi*x)dx = -4/(k*pi)

%b

F5 = @(x) 4/3 + symsum((1)*(4/k^2/pi^2 *cos(k*pi*x) - 4/k/pi*sin(k*pi*x)), k, 1, 5)
figure()
plot(-4:.1:4, F5(-4:.1:4))
title('F5')
F20 = @(x) 4/3 + symsum((1)*(4/k^2/pi^2 *cos(k*pi*x) - 4/k/pi*sin(k*pi*x)), k, 1, 20)
figure()
plot(-4:.1:4, F20(-4:.1:4))
title('F20')
F100 = @(x) 4/3 + symsum((1)*(4/k^2/pi^2 *cos(k*pi*x) - 4/k/pi*sin(k*pi*x)), k, 1, 100)
figure()
plot(-4:.1:4, F100(-4:.1:4))
title('F100')

%c

%cosine

%f(x) ~ a0/2 + sum(k=1 to inf)[ak*cos(k*pi*x/l)]
%with l=2
%a0 = 2/l*int(0 to l)f(x) dx = int(0 to 2)x^2 dx = 8/3
%ak = int(0 to 2)x^2*cos(k*pi*x/2) dx = 16/(k^2*pi^2)*(-1)^k
%f(x) ~ 4/3 + sum(k=1 to inf)[16/(k^2*pi^2)*(-1)^k*cos(k*pi*x/2)]

%sine

%f(x) ~ -sum(k=1 to inf)[(16/(k^3*pi^3)*(1-(-1)^k)+8/(k*pi)*(-1)^k)*sin(k*pi*x/2)]

%d

%cosine

Cos5 = @(x) 4/3 + symsum((1)*(16/k^2/pi^2 *(-1)^k*cos(k*pi*x/2) ), k, 1, 5)
figure()
plot(-4:.1:4, Cos5(-4:.1:4))
title('Cos5')
Cos20 = @(x) 4/3 + symsum((1)*(16/k^2/pi^2 *(-1)^k*cos(k*pi*x/2) ), k, 1, 20)
figure()
plot(-4:.1:4, Cos20(-4:.1:4))
title('Cos20')
Cos100 = @(x) 4/3 + symsum((1)*(16/k^2/pi^2 *(-1)^k*cos(k*pi*x/2) ), k, 1, 100)
figure()
plot(-4:.1:4, Cos100(-4:.1:4))
title('Cos100')

%sine

sin5 = @(x) -symsum((16 /k^3/pi^3*(1 - (-1)^k) + 8*(-1)^k/k/pi)*sin(k*pi*x/2), k, 1, 5)
figure()
plot(-4:.1:4,sin5(-4:.1:4))
title('Sin5')
sin20 = @(x) -symsum((16 /k^3/pi^3*(1 - (-1)^k) + 8*(-1)^k/k/pi)*sin(k*pi*x/2), k, 1, 20)
figure()
plot(-4:.1:4,sin20(-4:.1:4))
title('Sin20')
sin100 = @(x) -symsum((16 /k^3/pi^3*(1 - (-1)^k) + 8*(-1)^k/k/pi)*sin(k*pi*x/2), k, 1, 100)
figure()
plot(-4:.1:4,sin100(-4:.1:4))
title('Sin100')

%e

%Cosine converges the fastest