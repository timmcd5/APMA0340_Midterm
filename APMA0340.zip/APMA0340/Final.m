%APMA34 Final
%Jason Katz
%Should take about 2-3 minutes to run


%1

%a

syms x
syms n
An = simplify(simplify((2/120)*int((x/50)*sin(n*pi*x/120),x,0,50)) + simplify((2/120)*int(((120-x)/70)*sin(n*pi*x/120),x,50,120)));
u = @(x,t) eval(symsum(An*cos(3*n*pi*t/120)*sin(n*pi*x/120),n,1,100))

%b

figure()
for t = [1,5,15,25] 
uus=[];
for x=0:5:120
    uu = u(x,t);
    uus = [uus uu];
end
plot(0:5:120,uus)
hold on
end
legend('t=1','t=5','t=15','t=25','location','Best')
title('u versus x')

%c

figure()
for x = [15,25,47] 
uus=[];
for t = 0:35
    uu = u(x,t);
    uus = [uus uu];
end
plot(0:35,uus)
hold on
end
legend('x=15','x=25','x=47','location','Best')
title('u versus t')

%d

[x,t] = meshgrid(linspace(0,120,10),linspace(0,35,10));
uu = u(x,t);
figure()
surf(x,t,uu)
title('u versus t versus x')
%%

%2

%a

syms x
syms n
Bn = (2/(9*n*pi))*int(sin(n*pi*x/90),x,10,15);
u = @(x,t) eval(symsum(Bn*sin(9*n*pi*t/90)*sin(n*pi*x/90),n,1,100))

%b

figure()
for t = [1,3.5,11,18] 
uus=[];
for x=0:5:90
    uu = u(x,t);
    uus = [uus uu];
end
plot(0:5:90,uus)
hold on
end
legend('t=1','t=3.5','t=11','t=18','location','Best')
title('u versus x')

%c

figure()
for x = [10,40,60,85] 
uus=[];
for t = 0:.5:10
    uu = u(x,t);
    uus = [uus uu];
end
plot(0:.5:10,uus)
hold on
end
legend('x=10','x=40','x=60','x=85','location','Best')
title('u versus t')

%d

[x,t] = meshgrid(linspace(0,90,10),linspace(0,10,10));
uu = u(x,t);
figure()
surf(x,t,uu)
title('u versus t versus x')
%%

%3

%a

syms n
syms x
alpha = 2;
lambda_n = (pi*(1+2*n)/120)^2;
c_n = simplify((2/60)*int(x*(120-x)*cos(x*pi*(1+2*n)/120),x,0,60));
u = @(x,t) eval(symsum(c_n*exp(-alpha*lambda_n*t)*cos(x*pi*(1+2*n)/120),n,0,100))

%b

figure()
for x = [5,20,35,45,55] 
uus=[];
for t = 0:.5:5
    uu = u(x,t);
    uus = [uus uu];
end
plot(0:.5:5,uus)
hold on
end
legend('x=5','x=20','x=35','x=45','x=55','location','Best')
title('u versus t')

%c

figure()
for t = [1,2.5,4] 
uus=[];
for x = 0:5:60
    uu = u(x,t);
    uus = [uus uu];
end
plot(0:5:60,uus)
hold on
end
legend('t=1','t=2.5','t=4','location','Best')
title('u versus x')
%%

%4

%0<x<2, 0<y<3
%a=2, b=3, f(y)=2*y-5
%u(x,y)=X(x)*Y(y)
%X''(x)/X(x) = -Y''(y)/Y(y) = lambda^2
%u(x,y) = A_0 + symsum(A_n*cosh(n*pi*x/b)*cos(n*pi*y/b),n,1,inf)
%f(y) = u_x(a,y) = symsum((A_n(n*pi/b)*sinh(n*pi*a/b))*cos(n*pi*y/b),n,1,inf)
%a_0=-4
%NO SOLUTION - because a_0 does not equal 0
%%

%5

% 0<x<5, 0<y<3
%Yn(y) = An*cosh(n*pi*x/5) + Bn*sinh(n*pi*y/5)
%u(x,y) = sum(n=1 to inf)[sin(n*pi*x/5)*Bn*sinh(n*pi*y/5)]
%u(x,0) = 0
%u(x,3) = fourier series of sin = syms x, fourier(sin(x))
%u(x,y) = sum(n=1 to inf)[sin(n*pi*x/5)*fourier(sin(x))*sinh(n*pi*y/5)/sinh(n*pi*3/5)]
%%

%6

%r=6, f(v)=2-4*sin(6*v)
%a_n = (1/pi)*int(f(v)*cos(n*x),x,-pi,pi)
%b_n = (1/pi)*int(f(v)*sin(n*x),x,-pi,pi)
%u(r,v) = (a_0/2)*symsum((r^n)*(a_n*cos(n*v)+b_n*sin(n*v)),n,1,inf)
%u(r,v) = (a_0/2)*symsum(((a/r)^n)*(a_n*cos(n*v)+b_n*sin(n*v)),n,1,inf) >>> where (r>=a)
%r=6, f(v)=2-4*sin(6*v)
%%

%7

%r=6, f(v)=2-4*sin(6*v)
%a_n = (1/pi)*int(f(v)*cos(n*x),x,-pi,pi)
%b_n = (1/pi)*int(f(v)*sin(n*x),x,-pi,pi)
%a_0 = 0
%u(r,v) = (a_0/2)*symsum((r^n)*(a_n*cos(n*v)+b_n*sin(n*v)),n,1,inf)
%u(r,v) = (a_0/2)*symsum(((r/a)^n)*(a_n*cos(n*v)+b_n*sin(n*v)),n,1,inf) >>> where (r<=a)
%r=6, f(v)=2-4*sin(6*v)
%%

%8

%f(x) ~ a0/2 + sum(k=1 to inf)[ak*cos(k*pi*x/l) + bk*sin(k*pi*x/l)]
%with  l=2 >> f(x) ~ a0/2 + sum(k=1 to inf)[ak*cos(k*pi*x/2) + bk*sin(k*pi*x/2)]
%a0 = .5*int(-2 to 0)-dx + .5*int(0 to 2)x dx = 0
%ak = .5*int(-2 to 0)-cos(k*pi*x/2) dx + .5*int(0 to 2)x*cos(k*pi*x/2) dx = (2*cos(pi*k) + k*pi*sin(pi*k) - 2)/(k^2*pi^2)
%bk = .5*int(-2 to 0)-sin(k*pi*x/2) dx + .5*int(0 to 2)x*sin(k*pi*x/2) dx = (2*sin(pi*k) + pi*k - 3*k*pi*cos(pi*k))/(k^2*pi^2)

l=2;
a0 = 0;
ak = (2*cos(pi*k) + k*pi*sin(pi*k) - 2)/(k^2*pi^2);
bk = (2*sin(pi*k) + pi*k - 3*k*pi*cos(pi*k))/(k^2*pi^2);
f = @(x,N) eval((a0/2) + symsum(ak*cos(k*pi*x/l)+bk*sin(k*pi*x/l),k,1,N));
F5 = f(-2:.1:2,5);
figure()
plot(linspace(-2,0,20),linspace(-1,-1,20),'k','linewidth',2)
hold on
plot(linspace(0,2,21),linspace(0,2,21),'k','linewidth',2)
hold on
plot(linspace(-2,2,41),F5,'linewidth',2)
title('Fourier approximation for N=5')
F15 = f(-2:.1:2,15);
figure()
plot(linspace(-2,0,20),linspace(-1,-1,20),'k','linewidth',2)
hold on
plot(linspace(0,2,21),linspace(0,2,21),'k','linewidth',2)
hold on
plot(linspace(-2,2,41),F15,'linewidth',2)
title('Fourier approximation for N=15')
F30 = f(-2:.1:2,30);
figure()
plot(linspace(-2,0,20),linspace(-1,-1,20),'k','linewidth',2)
hold on
plot(linspace(0,2,21),linspace(0,2,21),'k','linewidth',2)
hold on
plot(linspace(-2,2,41),F30,'linewidth',2)
title('Fourier approximation for N=30')

%Cn(x) = a0/2 + sum(k=1 to N)[(1 - k/(N+1))*(ak*cos(k*pi*x/l) + bk*sin(k*pi*x/l))]
%a0 = .5*int(-2 to 0)-dx + .5*int(0 to 2)x dx = 0
%ak = .5*int(-2 to 0)-cos(k*pi*x/2) dx + .5*int(0 to 2)x*cos(k*pi*x/2) dx = (2*cos(pi*k) + k*pi*sin(pi*k) - 2)/(k^2*pi^2)
%bk = .5*int(-2 to 0)-sin(k*pi*x/2) dx + .5*int(0 to 2)x*sin(k*pi*x/2) dx = (2*sin(pi*k) + pi*k - 3*k*pi*cos(pi*k))/(k^2*pi^2)

l=2;
a0 = 0;
ak = (2*cos(pi*k) + k*pi*sin(pi*k) - 2)/(k^2*pi^2);
bk = (2*sin(pi*k) + pi*k - 3*k*pi*cos(pi*k))/(k^2*pi^2);
ces = @(x,N) eval((a0/2) + symsum((1 - k/(N+1))*(ak*cos(k*pi*x/l) + bk*sin(k*pi*x/l)),k,1,N));

C5 = ces(-2:.1:2,5);
figure()
plot(linspace(-2,0,20),linspace(-1,-1,20),'k','linewidth',2)
hold on
plot(linspace(0,2,21),linspace(0,2,21),'k','linewidth',2)
hold on
plot(linspace(-2,2,41),C5,'linewidth',2)
title('Cesaro sum for N=5')
C15 = ces(-2:.1:2,15);
figure()
plot(linspace(-2,0,20),linspace(-1,-1,20),'k','linewidth',2)
hold on
plot(linspace(0,2,21),linspace(0,2,21),'k','linewidth',2)
hold on
plot(linspace(-2,2,41),C15,'linewidth',2)
title('Cesaro sum for N=15')
C30 = ces(-2:.1:2,30);
figure()
plot(linspace(-2,0,20),linspace(-1,-1,20),'k','linewidth',2)
hold on
plot(linspace(0,2,21),linspace(0,2,21),'k','linewidth',2)
hold on
plot(linspace(-2,2,41),C30,'linewidth',2)
title('Cesaro sum for N=30')

%Overshoot: x=0
over_0_5 = -f(0,5)
over_0_15 = -f(0,15)
over_0_30 = -f(0,30)

%Undershoot: x=0
under_0_5 = f(0,5) + 1
under_0_15 = f(0,15) + 1
under_0_30 = f(0,30) + 1

%Undershoot: x=2
under_2_5 = 2 - f(2,5)
under_2_15 = 2 - f(2,15)
under_2_30 = 2 - f(2,30)