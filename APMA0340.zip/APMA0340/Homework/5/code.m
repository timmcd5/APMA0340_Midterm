%Homework #5 - Jason Katz

A1 = [2 2; 3 1]
A2 = [-3 -4; 2 1]
A3 = [3 -5; 2 1]
A4 = [-3 -2; 2 1]
A5 = [2 -5; 1 -2]
A6 = [3 -1; 1 1]
A7 = [2 1; 1 2]

eig(A1)
eig(A2)
eig(A3)
eig(A4)
eig(A5)
eig(A6)
[v, d] = eig(A7)

%1

%A1 = Saddle Point
%A2 = Spiral Point
%A3 = Spiral Point
%A4 = Improper Nodal Sink
%A5 = Center
%A6 = Improper/Degenerate Node
%A7 = Nodal Source


%2

%A1 = Unstable
%A2 = Asymptotically Stable
%A3 = Unstable
%A4 = Asymptotically Stable
%A5 = Stable
%A6 = Unstable
%A7 = Unstable


%3

%A1
[x1,y1] = meshgrid(-2:0.1:2);
dxdt1 = 2*x1+2*y1;
dydt1 = 3*x1+1*y1;
r1 = sqrt(dxdt1.^2+dydt1.^2);
px1 = dxdt1./r1;
py1 = dydt1./r1;
figure()
quiver(x1,y1,px1,py1);
title('A1 Direction Field and Solutions')
f1 = @(t,Y) [2*Y(1) + 2*Y(2); 3*Y(1) + 1*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f1,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f1,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])

%A2
[x2,y2] = meshgrid(-2:0.1:2);
dxdt2 = -3*x2-4*y2;
dydt2 = 2*x2+1*y2;
r2 = sqrt(dxdt2.^2+dydt2.^2);
px2 = dxdt2./r2;
py2 = dydt2./r2;
figure()
quiver(x2,y2,px2,py2);
title('A2 Direction Field and Solutions')
f2 = @(t,Y) [-3*Y(1) + -4*Y(2); 2*Y(1) + 1*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f2,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f2,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])

%A3
[x3,y3] = meshgrid(-2:0.1:2);
dxdt3 = 3*x3-5*y3;
dydt3 = 2*x3+1*y3;
r3 = sqrt(dxdt3.^2+dydt3.^2);
px3 = dxdt3./r3;
py3 = dydt3./r3;
figure()
quiver(x3,y3,px3,py3);
title('A3 Direction Field and Solutions')
f3 = @(t,Y) [3*Y(1) + -5*Y(2); 2*Y(1) + 1*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f3,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f3,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])

%A4
[x4,y4] = meshgrid(-2:0.1:2);
dxdt4 = -3*x4-2*y4;
dydt4 = 2*x4+1*y4;
r4 = sqrt(dxdt4.^2+dydt4.^2);
px4 = dxdt4./r4;
py4 = dydt4./r4;
figure()
quiver(x4,y4,px4,py4);
title('A4 Direction Field and Solutions')
f4 = @(t,Y) [-3*Y(1) + -2*Y(2); 2*Y(1) + 1*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f4,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f4,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])

%A5
[x5,y5] = meshgrid(-2:0.1:2);
dxdt5 = 2*x5-5*y5;
dydt5 = 1*x5-2*y5;
r5 = sqrt(dxdt5.^2+dydt5.^2);
px5 = dxdt5./r5;
py5 = dydt5./r5;
figure()
quiver(x5,y5,px5,py5);
title('A5 Direction Field and Solutions')
f5 = @(t,Y) [2*Y(1) + -5*Y(2); 1*Y(1) + -2*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f5,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f5,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])

%A6
[x6,y6] = meshgrid(-2:0.1:2);
dxdt6 = 3*x6-1*y6;
dydt6 = 1*x6+1*y6;
r6 = sqrt(dxdt6.^2+dydt6.^2);
px6 = dxdt6./r6;
py6 = dydt6./r6;
figure()
quiver(x6,y6,px6,py6);
title('A6 Direction Field and Solutions')
f6 = @(t,Y) [3*Y(1) + -1*Y(2); 1*Y(1) + 1*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f6,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f6,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])

%A7
[x7,y7] = meshgrid(-2:0.1:2);
dxdt7 = 2*x7+1*y7;
dydt7 = 1*x7+2*y7;
r7 = sqrt(dxdt7.^2+dydt7.^2);
px7 = dxdt7./r7;
py7 = dydt7./r7;
figure()
quiver(x7,y7,px7,py7);
title('A7 Direction Field and Solutions')
f7 = @(t,Y) [2*Y(1) + 1*Y(2); 1*Y(1) + 2*Y(2)];
hold on 
for theta=-2:.75:2
    for beta=-2:.75:2
    x0=[theta beta];
    [t,x]=ode45(f7,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    x0=[theta beta];
    [t,x]=ode45(f7,[0 2],x0);
    plot(x(:,1),x(:,2), 'k', 'LineWidth', 2)
    end
end
axis([-2 2 -2 2])
