I2 = [1 0; 0 1]
I3 = [1 0 0; 0 1 0; 0 0 1]
I4 = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1]
syms x
syms t

%Problem 1

%Part a

%Root 1
A = [25 -24; -26 48]
A_Res = inv(x*I2 - A)
A2 = x*I2-A
A3 = cofactor(A2)
A4 = transpose(A3)
A5 = factor(det(A4))
A6 = ((-3/55)*subs(A4, x, 9) + (8/55)*subs(A4, x, 64))
%Root 2
A_eig = eig(A)
A_Z_9 = 55*(A-64*I2)/(9-64)
A_Z_64 = 55*(A-9*I2)/(64-9)
A_sqrt_1 = 5*((9^.5)*A_Z_9/55 - (64^.5)*A_Z_64/55)

%Part b
B = [37 -60 48; 27 -44 36; 9 -15 13]
B_Res = inv(x*I3 - B)
B2 = x*I3-B
B3 = cofactor(B2)
B4 = transpose(B3)
B5 = factor(det(B4))
B6 = (-1/3)*subs(B4, x, 1) + (2/3)*subs(B4, x, 4)

%Root 1
[v, d] = eig(B)
d_sq = sqrtm(d)
R1 = v*d_sq/(v)

%Root 2
d_sq(1,1) = -2
R2 = v*d_sq/v

%Root 3
d_sq = sqrtm(d)
d_sq(2,2) = -1
R3 = v*d_sq/v

%Root 4
d_sq = sqrtm(d)
d_sq(3,3) = -1
R4 = v*d_sq/v

%Problem 2

%Part A1
A6*(sin(sqrtm(A)*t)/sqrtm(A))*A_Res

%Part A2
A6*(cos(sqrtm(A)*t))*A_Res

%Part B1
B6*(sin(sqrtm(B)*t)/sqrtm(B))*B_Res

%Part B2
B6*(cos(sqrtm(B)*t))*B_Res

%Problem 3

%Part (a)
Z9 = [39 24; 26 16]/55
Z64 = [16 -24; -26 39]/55
isequal(round(9*Z9, 10), round(A*Z9,10))
isequal(round(64*Z64, 10), round(A*Z64,10))

%Part (b)
Z1 = (-1/3)*[33 -60 48; 27 -48 36; 9 -15 9]
Z4 = [36 -60 48; 27 -45 36; 9 -15 12]/3
isequal(round(Z1, 10), round(B*Z1,10))
isequal(round(4*Z4, 10), round(B*Z4,10))

%Problem 4

C = [-13 6 18; -4 1 4; -21 6 26]
C_Res = inv(x*I3 - C)
C2 = x*I3-C
C3 = cofactor(C2)
C4 = transpose(C3)
C5 = factor(det(C4))
Z1 = (C-5*I3)*(C-8*I3)/(1-5)/(1-8)
Z5 = (C-I3)*(C-8*I3)/(5-1)/(5-8)
Z8 = (C-I3)*(C-5*I3)/(8-1)/(8-5)
IT = exp(t)*Z1+exp(5*t)*Z5+exp(8*t)*Z8
WT = cos(t)*Z1 + cos(5*t)*Z5 + cos(8*t)*Z8
isequal(exp(t)*Z1+5*exp(5*t)*Z5+8*exp(8*t)*Z8, C*IT)
isequal(-cos(t)*Z1 -25*cos(5*t)*Z5 - 64*cos(8*t)*Z8,-(C^2)*WT)

%Problem 5

D = [-170 54 234; -133 43 182; -95 30 131]
D_Res = inv(x*I3 - D)
D2 = x*I3-D
D3 = cofactor(D2)
D4 = transpose(D3)
D5 = factor(det(D4))
Z1 = (D-2*I3)/(1-2)
Z2 = (D-I3)/(2-1)
IT = exp(t)*Z1+exp(2*t)*Z2
WT = cos(t)*Z1 + cos(2*t)*Z2
isequal(exp(t)*Z1+2*exp(2*t)*Z2, D*IT)
isequal(-cos(t)*Z1 -4*cos(2*t)*Z2,-(D^2)*WT)