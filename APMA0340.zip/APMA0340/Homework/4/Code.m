I2 = [1 0; 0 1]
I3 = [1 0 0; 0 1 0; 0 0 1]
I4 = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1]
syms x
syms t

%Problem 1

%Part a

A = [-3 6 3; -3 1 4; -1 6 1]
A_Res = inv(x*I3 - A)
A2 = x*I3-A
A3 = cofactor(A2)
A4 = transpose(A3)
A5 = factor(det(A4))
A6 = subs(simplify(diff(simplify(A_Res*((x+2)^2)*exp(x*t)), x)), x, -2)
A7 = subs(simplify(A_Res*(x-3)*exp(x*t)), x, 3)
IT = A6+A7

%Part b

A8 = subs(simplify(diff(simplify(A_Res*((x+2)^2)*sin(x*t)/x), x)), x, -2)
A9 = subs(simplify(A_Res*(x-3)*sin(x*t)/x), x, 3)
WT = A8+A9

%Part c

isequal(simplify(diff(IT, t)), simplify(A*IT))
isequal(double(subs(IT, t, 0)), I3)

%Part d
A10 = subs(simplify(diff(simplify(A_Res*((x+2)^2)*exp(-x*t)), x)), x, -2)
A11 = subs(simplify(A_Res*(x-3)*exp(-x*t)), x, 3)
IT_I = A10+A11
 
isequal(double(simplify(IT_I*IT)), I3)

%Part e

isequal(double(subs(WT, t, 0)), 0*I3)
isequal(double(subs(diff(WT, t), t, 0)), I3)
isequal(double(diff(diff(WT, t))+WT*A^2), 0*I3)


%Problem 2

%Part a

B = [8 0 -4; 3 4 1; -8 0 12]
B_Res = inv(x*I3 - B)
B2 = x*I3-B
B3 = cofactor(B2)
B4 = transpose(B3)
B5 = factor(det(B4))


B10 = subs(simplify(diff(simplify(simplify(B_Res*((x-4)^2))*(x^.5)), x)), x, 4)
B11 = subs(simplify(B_Res*(x-16)*x^.5), x, 16)

%Root 1
R1 = B10+B11

%Root 2
R2 = B10-B11

%Root 3
R3 = -B10+B11

%Root 4
R4 = -B10-B11

%Part b

B6 = subs(simplify(diff(simplify(simplify(B_Res*((x-4)^2))*exp(x*t)), x)), x, 4)
B7 = subs(simplify(B_Res*(x-16)*exp(x*t)), x, 16)
IT = B6+B7

%Part c

B8 = subs(simplify(diff(simplify(simplify(B_Res*((x-4)^2))*sin(x^.5*t)/x^.5), x)), x, 4)
B9 = subs(simplify(simplify(B_Res*(x-16))*sin(x^.5*t)/x^.5), x, 16)
WT = B8+B9

%Part d

isequal(diff(IT, t), B*IT)
isequal(double(subs(IT, t, 0)), I3)

%Part e

isequal(double(diff(diff(WT, t), t)+B*WT),0*I3)
isequal(double(subs(WT, t, 0)), 0*I3)
isequal(double(subs(diff(WT, t), t, 0)), I3)

%Problem 3


fun = @root4d;
x0 = [0,0,0,0];
x = fsolve(fun,x0)
%No solution means that there is no square root

syms x
c = [1 1; -1 -1]
c_Res = inv(x*I2 - c)
c2 = x*I2-c
c3 = cofactor(c2)
c4 = transpose(c3)
c5 = factor(det(c4))
root = subs(simplify(diff(simplify(c_Res*((x)^2)*x^.5), t)), x, -1)
wt = (-(t^3)/6)*c + t*I2
isequal(double(diff(diff(wt)) + c*wt),0*I2)
isequal(double(subs(wt, t, 0)), 0*I2)
isequal(double(subs(diff(wt), t, 0)), I2)

function F = root4d(x)

F(1) = x(1)^2 +x(2)*x(3) -1;
F(2) = x(1)*x(2)+x(2)*x(4)-1;
F(3) = x(3)*x(1)+x(4)*x(3)+1;
F(4) = x(3)*x(2)+x(4)^2+1;

end