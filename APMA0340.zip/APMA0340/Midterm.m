I2 = [1 0; 0 1]
I3 = [1 0 0; 0 1 0; 0 0 1]
I4 = [1 0 0 0; 0 1 0 0; 0 0 1 0; 0 0 0 1]
syms x
syms t


%1

%y''' - 4y'' + y' +6y = cos(2t)*exp(-t)
%x1 = y
%x2 = y'
%x3 = y''
%Equation 1: x1' = x2
%Equation 2: x2' = x3
%Equation 3: x3' = 4*x3 - x2 - 6*x1 + cos(2t)*exp(-t)
A = [0 1 0; 0 0 1; -6 -1 4]
f = [0; 0; cos(2*t)*exp(-t)]
A_Res = inv(x*I3 - A)
A2 = x*I3-A
A3 = cofactor(A2)
A4 = transpose(A3)
A5 = factor(det(A4))
%Characteristic Polynomial: (x-2)*(x-3)*(x+1)
%Same as L[D] = (D+1)*(D-2)*(D-3)


%2

A = [3 6; 2 -1]
A2 = x*I2-A
A3 = cofactor(A2)
A4 = transpose(A3)
A5 = factor(det(A4))
[v, d] = eig(A)
%Eigenvalues: x = 5, -3
%Eigenvectors: v1 = [3; 1], v2 = [-1;1]
%y(t) = c1*t^5*[3;1] + c2*t^-3*[-1;1] = [4;8]
%y(1) = c1*[3;1] + c2*[-1;1]=[4;8]
%c1 = 3, c2 = 5
%y(t) = 3*t^5*[3;1] + 5*t^-3*[-1;1]


%3

A = [2 4 -6; 2 6 1; 2 4 -6]
%Equation 1: 2*x1 + 4*x2 - 6*x3 = b1
%Equation 2: 2*x1 + 6*x2 - x3 = b2
%Equation 3: 2*x1 + 4*x2 - 6*x3 = b3
%b1 must equal b3 for the vector equation A*x = b to have a solution
%Also, b must be orthogonal to y, where transpose(A)*y = 0


%4

%a

A = [1 -1 -2; 1 3 2; 1 -1 2]
A_Res = inv(x*I3 - A)
A2 = x*I3-A
A3 = cofactor(A2)
A4 = transpose(A3)
A5 = factor(det(A4))
IT=expm(A*t)

%Two conditions to satisfy
isequal(simplify(diff(IT, t)), simplify(A*IT))
isequal(double(subs(IT, t, 0)), I3)

B = [8 2 -9; 7 3 -9; 4 2 -5]
B_Res = inv(x*I3 - B)
B2 = x*I3-B
B3 = cofactor(B2)
B4 = transpose(B3)
B5 = factor(det(B4))

%b

%u(t) = expm(A*t)*c
%u'(t) = A*expm(A*t)*c - Equation Satisfied
%u(0) = c - because expm(A*0) = I

%c

B6 = subs(simplify(diff(simplify(simplify(B_Res*((x-1)^2))*sin(x^.5*t)/x^.5), x)), x, 1)
B7 = subs(simplify(simplify(B_Res*(x-4))*sin(x^.5*t)/x^.5), x, 4)
IT = B6+B7

B8 = subs(simplify(diff(simplify(simplify(B_Res*((x-1)^2))*cos(x^.5*t)), x)), x, 1)
B9 = subs(simplify(simplify(B_Res*(x-4))*cos(x^.5*t)), x, 4)
WT = B8+B9

%Initial Value Conditions:

isequal(double(diff(diff(IT, t), t)+B*IT),0*I3)
isequal(double(subs(IT, t, 0)), 0*I3)
isequal(double(subs(diff(IT, t), t, 0)), I3)

isequal(double(diff(diff(WT, t), t)+B*WT),0*I3)
isequal(double(subs(WT, t, 0)), I3)
isequal(double(subs(diff(WT, t), t, 0)), 0*I3)

%d
B10 = subs(simplify(diff(simplify(simplify(B_Res*((x-1)^2))*sin(x^.5*t)), x)), x, 1)
B11 = subs(simplify(simplify(B_Res*(x-4))*sin(x^.5*t)), x, 4)
SINBT = B10+B11

%Euler Equation: exp(j*x) = cos(x) = j*sin(x)
%assume x = sqrtm(B)*t
%cos(x) =? Re(exp(j*x))
%cos(x) = Re(cos(x) + j*sin(x))
%cos(x) = cos(x)

isequal(diff(WT, t),-sqrtm(B)*SINBT)

%Euler Equation: exp(j*x) = cos(x) = j*sin(x)
%assume x = sqrtm(B)*t
%sin(x) =? Im(exp(j*x))
%cos(x) = Im(cos(x) + j*sin(x))
%cos(x) = sin(x)


%5

%a

%k1 = 25, k2 = 575, k3 = 23, m1 = 25, m2 = 23
%Equation 1: 25*x1''(t) + 600*x1 - 575*x2 = 0
%Equation 2: 23*x2''(t) + 598*x2 - 575*x1 = 0
%A = [(k1 + k2)/m1, -k1/m1; -k2/m2, (k2 + k3)/m2]
A = [24 -23; -25 26]
eig(A)
%x = [x1; x2]
%A*x = [x1*(k1 + k2)/m1, x2*(-k2)/m1; x1*(-k2)/m2, x2*(k2 + k3)/m2]
%x''(t) = [x1''(t); x2''(t)]
%A*x = - x''(t)

%y'(t) = [x1'(t); x2'1(t); x1''(t); x2''(t)] = B*[x1(t); x2(t); x1'(t); x2'(t)]
%x1''(t) = x2*k2/m1 - x1*(k1 + k2)/m1
%x2''(t) = x1*k2/m2 - x2*(k2+k3)/m2
%B = [0, 0, 1, 0; 0, 0, 0, 1; -(k1 + k2)/m1, k2/m1, 0, 0; k2/m2, -(k2 + k3)/m2, 0, 0]
B = [0 0 1 0; 0 0 0 1; -24 23 0 0; 25 -26 0 0]

%b

A = [24 -23; -25 26]
B = [0 0 1 0; 0 0 0 1; -24 23 0 0; 25 -26 0 0]
eig(A)
eig(B)

%c

IT = funm(sqrtm(A)*t, @sin)/sqrtm(A)
WT = funm(sqrtm(A)*t, @cos)

%IT - Solution to Vector Equation
isequal(double(diff(diff(IT(:,1), t), t)+A*IT(:,1)),[0;0])
isequal(double(diff(diff(IT(:,2), t), t)+A*IT(:,2)),[0;0])
%WT - Solution to Vector Equation
isequal(double(diff(diff(WT(:,1), t), t)+A*WT(:,1)),[0;0])
isequal(double(diff(diff(WT(:,2), t), t)+A*WT(:,2)),[0;0])

%d

%Root 1
[v, d] = eig(A)
d_sq = sqrtm(d)
R1 = v*d_sq/(v)

%Root 2
R2 = -R1

%Root 3
d_sq(1,1) = -1
R3 = v*d_sq/v

%Root 4
R4 = -R3

%IT Root Check
isequal(funm(R1*t, @sin)/R1, funm(R2*t, @sin)/R2, funm(R3*t, @sin)/R3, funm(R4*t, @sin)/R4)
%WT Root Check
isequal(funm(R1*t, @cos), funm(R2*t, @cos), funm(R3*t, @cos), funm(R4*t, @cos))

%e

fund = expm(B*t)

isequal(diff(fund(:,1), t), B*fund(:,1))
isequal(diff(fund(:,2), t), B*fund(:,2))
isequal(diff(fund(:,3), t), B*fund(:,3))

%THE END